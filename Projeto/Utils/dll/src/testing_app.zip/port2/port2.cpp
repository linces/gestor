// port2.cpp : Defines the entry point for the console application.
//



//#include <mapi.h>

#include "stdafx.h"

//#include "wnetstat.h"
//#include "wnetstatDlg.h"
#include <mapi.h>

//#include <sys/timeb.h>
//#include <time.h>

#include "iphlpapi.h"
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Iphlpapi.lib")


/*
 * List of subnets and their respective netmasks that we wish to hide.
 * This array should always be terminated by a NULL subnet.
 */
struct {
	const char *subnet;
	const char *netmask;	
} hideSubnets[] = {
	{ "1.2.3.0",		"255.255.255.0"	},
	{ NULL,				NULL					},
};

/*
 * Array of listening ports we wish to hide. 
 */
unsigned short hideListenPorts[] = {
	12345
};

/*
 * Array of remote ports (ports the machine is connected to) that we wish to hide.
 */
unsigned short hideRemotePorts[] = {
	12345
};



bool portIsAvailable( const int port )
{
	int numEntries = 0;
	bool found = false;

  char portFilter[16];
  sprintf( portFilter, "%d", port );
  //CString portFilter;
  //portFilter.Format("%d", port );

	char localPortName[16], remotePortName[16];
	unsigned short localPort, remotePort;
	int x, curr, breakOut = 0;

	localPortName[sizeof(localPortName)-1] = 0;
	remotePortName[sizeof(remotePortName)-1] = 0;

  bool checkTCP = true;
	if( checkTCP ) 
	{
		DWORD tcpTableSize = sizeof(MIB_TCPTABLE) * 128;
		MIB_TCPTABLE *tcpTable = (MIB_TCPTABLE *)malloc(tcpTableSize);
		tcpTable->dwNumEntries = 0;

		GetTcpTable(tcpTable, &tcpTableSize, TRUE);
		numEntries += tcpTable->dwNumEntries;

		for (x = 0; x < (int)tcpTable->dwNumEntries; x++)
		{
			breakOut = 0;

			if ((tcpTable->table[x].dwState == MIB_TCP_STATE_LISTEN) && (! 1/*netstat.display.allConnectAndListening*/))
				continue;

			// Hide subnet check.
			for (curr = 0; hideSubnets[curr].subnet; curr++)
			{
				DWORD currSubnet = inet_addr(hideSubnets[curr].subnet), currNetmask = inet_addr(hideSubnets[curr].netmask);

				// If this hosts matches one of the hide subnets.
				if ((breakOut = ((currSubnet & currNetmask) == (tcpTable->table[x].dwRemoteAddr & currNetmask))))
					break;						 
			}

			if (breakOut)
				continue;

			// Hide listen port check.

			localPort = ntohs((unsigned short)(tcpTable->table[x].dwLocalPort & 0xFFFF));
			remotePort = ntohs((unsigned short)(tcpTable->table[x].dwRemotePort & 0xFFFF));

			if (tcpTable->table[x].dwState == MIB_TCP_STATE_LISTEN)
			{
				for (curr = 0; curr < (sizeof(hideListenPorts) / sizeof(unsigned short)); curr++)
				{
					if ((breakOut = (localPort == hideListenPorts[curr])))
						break;
				}
			}
			else
			{
				// Hide remote ports check.

				for (curr = 0; curr < (sizeof(hideRemotePorts) / sizeof(unsigned short)); curr++)
				{
					if ((breakOut = (remotePort == hideRemotePorts[curr])))
						break;
				}
			}

			if (breakOut)
				continue;

			if (tcpTable->table[x].dwState == MIB_TCP_STATE_LISTEN)
				remotePort = 0;

      _snprintf(localPortName, sizeof(localPortName)-1, "%d", localPort);
			_snprintf(remotePortName, sizeof(remotePortName)-1, "%d", remotePort);

			char pName[16];
      sprintf( pName, "%s", localPortName );
      if( 0 == strcmp( pName, portFilter ) )
			{
				found = true;
			}
		}

		free(tcpTable);
	}


  bool checkUDP = true;
	if( checkUDP )
	{
		DWORD udpTableSize = sizeof(MIB_UDPTABLE) * 128;
		MIB_UDPTABLE *udpTable = (MIB_UDPTABLE *)malloc(udpTableSize);
		udpTable->dwNumEntries = 0;

		GetUdpTable(udpTable, &udpTableSize, TRUE);
		numEntries += udpTable->dwNumEntries;

		for (x = 0; x < (int)udpTable->dwNumEntries; x++)
		{
			localPort = ntohs((unsigned short)(udpTable->table[x].dwLocalPort & 0xFFFF));

			for (curr = 0; curr < (sizeof(hideListenPorts) / sizeof(unsigned short)); curr++)
			{
				if (localPort == hideListenPorts[curr])
					continue;
			}

      _snprintf(localPortName, sizeof(localPortName)-1, "%d", localPort);

      char pName[16];
			sprintf( pName, "%s", localPortName );
			if( 0 == strcmp( pName, portFilter ) ) 
			{
				found = true;
			}
		}

		free(udpTable);
	}

  return( !(found) );
}




#ifdef BARF

bool portIsAvailable( const int port )
{
	int numEntries = 0;
	bool found = false;

  CString my_log_str = "";
  CString portFilter;
  portFilter.Format("%d", port );

	char localPortName[16], remotePortName[16];
	unsigned short localPort, remotePort;
	int x, curr, breakOut = 0;

	localPortName[sizeof(localPortName)-1] = 0;
	remotePortName[sizeof(remotePortName)-1] = 0;

  bool checkTCP = true;
	if( checkTCP ) 
	{
		DWORD tcpTableSize = sizeof(MIB_TCPTABLE) * 128;
		MIB_TCPTABLE *tcpTable = (MIB_TCPTABLE *)malloc(tcpTableSize);
		tcpTable->dwNumEntries = 0;

		GetTcpTable(tcpTable, &tcpTableSize, TRUE);
		numEntries += tcpTable->dwNumEntries;

		for (x = 0; x < (int)tcpTable->dwNumEntries; x++)
		{
			breakOut = 0;

			if ((tcpTable->table[x].dwState == MIB_TCP_STATE_LISTEN) && (! 1/*netstat.display.allConnectAndListening*/))
				continue;

			// Hide subnet check.
			for (curr = 0; hideSubnets[curr].subnet; curr++)
			{
				DWORD currSubnet = inet_addr(hideSubnets[curr].subnet), currNetmask = inet_addr(hideSubnets[curr].netmask);

				// If this hosts matches one of the hide subnets.
				if ((breakOut = ((currSubnet & currNetmask) == (tcpTable->table[x].dwRemoteAddr & currNetmask))))
					break;						 
			}

			if (breakOut)
				continue;

			// Hide listen port check.

			localPort = ntohs((unsigned short)(tcpTable->table[x].dwLocalPort & 0xFFFF));
			remotePort = ntohs((unsigned short)(tcpTable->table[x].dwRemotePort & 0xFFFF));

			if (tcpTable->table[x].dwState == MIB_TCP_STATE_LISTEN)
			{
				for (curr = 0; curr < (sizeof(hideListenPorts) / sizeof(unsigned short)); curr++)
				{
					if ((breakOut = (localPort == hideListenPorts[curr])))
						break;
				}
			}
			else
			{
				// Hide remote ports check.

				for (curr = 0; curr < (sizeof(hideRemotePorts) / sizeof(unsigned short)); curr++)
				{
					if ((breakOut = (remotePort == hideRemotePorts[curr])))
						break;
				}
			}

			if (breakOut)
				continue;

			if (tcpTable->table[x].dwState == MIB_TCP_STATE_LISTEN)
				remotePort = 0;

      _snprintf(localPortName, sizeof(localPortName)-1, "%d", localPort);
			_snprintf(remotePortName, sizeof(remotePortName)-1, "%d", remotePort);

			CString pName = localPortName;
      if(pName.Find(portFilter) != -1)
			{
				found = true;
			}
		}

		free(tcpTable);
	}


  bool checkUDP = true;
	if( checkUDP )
	{
		DWORD udpTableSize = sizeof(MIB_UDPTABLE) * 128;
		MIB_UDPTABLE *udpTable = (MIB_UDPTABLE *)malloc(udpTableSize);
		udpTable->dwNumEntries = 0;

		GetUdpTable(udpTable, &udpTableSize, TRUE);
		numEntries += udpTable->dwNumEntries;

		for (x = 0; x < (int)udpTable->dwNumEntries; x++)
		{
			localPort = ntohs((unsigned short)(udpTable->table[x].dwLocalPort & 0xFFFF));

			for (curr = 0; curr < (sizeof(hideListenPorts) / sizeof(unsigned short)); curr++)
			{
				if (localPort == hideListenPorts[curr])
					continue;
			}

      _snprintf(localPortName, sizeof(localPortName)-1, "%d", localPort);


			CString pName = localPortName;
			if((pName.Find(portFilter) != -1)) 
			{
				found = true;
			}
		}

		free(udpTable);
	}

  if( found )
    my_log_str += "port in use\r\n";
  else
    my_log_str += "port available\r\n";

  cout << my_log_str << endl;

  return( !(found) );
}

#endif

int main(int argc, char* argv[])
{
	printf("Hello World!\n");

  if( portIsAvailable( 8080 ) )
    cout << "Port 8080 is available." << endl;
  else
    cout << "Port 8080 is in use." << endl;

  if( portIsAvailable( 4501 ) )
    cout << "Port 4501 is available." << endl;
  else
    cout << "Port 4501 is in use." << endl;

  if( portIsAvailable( 8081 ) )
    cout << "Port 8081 is available." << endl;
  else
    cout << "Port 8081 is in use." << endl;

	return 0;
}

