//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wnetstat.rc
//
#define IDD_WNETSTAT_DIALOG             102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_EDIT_STATS                  1000
#define IDC_BUTTON_CHECK                1001
#define IDC_CHECK_RESOLVE               1002
#define IDC_COMBO_FILTER                1003
#define IDC_COMBO_PROTOCOL              1004
#define IDC_CHECK_MONITOR               1005
#define IDC_BUTTON_CLEAR                1006
#define IDC_CHECK_SENDEMAIL             1009
#define IDC_EDIT_EMAILADDRESS           1010
#define IDC_EDIT_PORTFILTER             1011
#define IDC_EDIT_IPFILTER               1012
#define IDC_CHECK_PORTFILTER            1013
#define IDC_CHECK_IPFILTER              1014
#define IDC_BUTTON_SAVE                 1015
#define IDC_CHECK_LOG                   1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
