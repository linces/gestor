# delphi-msg
 Programa feito em Delphi para exibir mensagens na tela, uma especie de ALERT do JS com muitas outras opções. O objetivo desse programa é ser usado conjuntamente com outros scripts ou programas que não tem essa capacidade ou se tem torna mais complexa a programação. As opções são as seguintes:
-DEL=Apaga o arquivo após a exibição
-MSG=Mensagem Texto
   A mensagem a ser exibida, se ela for de até 120 caracteres será exibida no system tray do Windows.
-I=Arquivo ou -INPUT=Arquivo
   A mensagem a ser exibida será carregada a partir de um arquivo definido.
   São aceitos arquivos .TXT ou .RTF.
-C=Titulo da janela ou -CAPTION=Titulo da Janela
   A Mensagem ou texto a ser exibido como titulo da janela.
-T=TempoSegundos ou -TIME=TempoSegundos
  Autofecha a janela após a quantidade de segundos que for definida.
